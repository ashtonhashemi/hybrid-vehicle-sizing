eng = FC_SI41_emis_mod;
hold on;
plot(eng.w,eng.tm);
% contour(eng.w,eng.t,eng.co2_g_kwh,50);

[a,b] = contour(eng.w,eng.t,eng.nox_g_kwh,10);
clabel(a,b);