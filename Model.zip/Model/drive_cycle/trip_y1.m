%automatic save from building a trip

cyc_description='trip_y1.m';
cyc_version=2002;
cyc_proprietary=0;
cyc_validation=0;
load trip_y1.mat

cyc_avg_time=1;  % (s)
cyc_filter_bool=0;
cyc_elevation_init=0;

%Revision History:
% automatically created in ADVISOR 2002 on 04-Sep-2005