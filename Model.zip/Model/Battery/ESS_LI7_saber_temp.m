% ADVISOR data file:  ESS_LI7_saber_temp.m
%
% Data source: 
%
% Data confirmation: 
%
% Created on: 21-Dec-2001
% By: VHJ, valerie_johnson@nrel.gov
%
% Revision history at end of file.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FILE ID INFO
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ess_description='7 Ah Saft Lithium Ion battery in Saber'; 
ess_version=2002; % version of ADVISOR for which the file was generated
ess_proprietary=0; % 0=> non-proprietary, 1=> proprietary, do not distribute
ess_validation=2; % 0=> no validation, 1=> data agrees with source data, 
% 2=> data matches source data and data collection methods have been verified
disp(['Data loaded: ESS_LI7_saber_temp.m - ',ess_description])

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input Data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% General info on the Saber model:
% Saber model is the RC battery model
% Parameters (Cb,Cc,Re,Rt,Rc) as they vary with temperature and SOC (R's)
%           are detailed in files in the models\Saber\Battery directory: 
%           (change these to change the base values). LIB stands for Lithium Ion Battery
%           LIB_Cb.ai_dat, LIB_Cc.ai_dat,LIB_Re.ai_dat,LIB_Rc.ai_dat,LIB_Rt.ai_dat
%           LIB_Cb.ai_tlu, LIB_Cc.ai_tlu,LIB_Re.ai_tlu,LIB_Rc.ai_tlu,LIB_Rt.ai_tlu
%           Cb & Cc indexed by temperature, Re, Rc & Rt indexed by SOC and Temp
% The base schematics/sin files have 10 modules, below user can alter 
%           additional parameters for each of these 10 modules.
% To increase the voltage of the pack, the user can scale the 10 modules, using Vnom_set.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Nominal voltage of the pack, used below to calculate number of '10 cell pack' modules
Vnom_set=288;
% Calculate module number, the number of '10 cell modules', found using nominal pack voltage
%   scale factor for 10 LiIon batteries is 10cell*3.6V/cell=36V
ess_module_num=Vnom_set/(10*3.6);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Scale factors, 'k' values, indexed by module number
% Value >1 increases parameters (R's & C's), e.g. 1.1 = 10% increase
% Value <1 decreases parameters (R's & C's), e.g. 0.85 = 15% decrease
saber_k_re=[1 1 1 1 1 1 1 1 1 1];
saber_k_rc=[1 1 1 1 1 1 1 1 1 1];
saber_k_rt=[1 1 1 1 1 1 1 1 1 1];
saber_k_cb=[1 1 1 1 1 1 1 1 1 1];
saber_k_cc=[1 1 1 1 1 1 1 1 1 1];

% SOC integrator factor, k = Inverse of Energy Capacity of Battery - Units = 1/Joules for integ
saber_k_soc=[1 1 1 1 1 1 1 1 1 1]*1.2744210942e-05;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Open Circuit Voltage
%
% SOC RANGE over which OCV is defined
ess_soc=[0 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 1];  % (--)	

% Temperature range over which OCV is defined
ess_tmp=[1 25 45];  % (C)

% Module's open-circuit voltage, indexed by ess_soc and ess_tmp
ess_voc=[3.44 3.496 3.514 3.532 3.55 3.568 3.585 3.602 3.62 3.637 3.667 3.697 3.727 3.757 3.896;
    3.124 3.36 3.42 3.479 3.501 3.524 3.547 3.569 3.593 3.616 3.65 3.684 3.72 3.756 3.9;
    3.128 3.365 3.425 3.484 3.506 3.528 3.552 3.575 3.599 3.623 3.657 3.692 3.727 3.761 3.899]; % (V)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial Values
%
% Initial SOC's, indexed by module number
saber_init_soc=[1 1 1 1 1 1 1 1 1 1]*0.7;%6226;
% Calculate the initial voltages on the capacitors at given temp, e.g. 25C
saber_init_voc=interp2(ess_soc,ess_tmp,ess_voc,saber_init_soc,25);

% Initial temps's (deg C), indexed by module number
saber_init_temp=[1 1 1 1 1 1 1 1 1 1]*25;
%saber_init_temp=[1 0.95 0.9 0.85 1.05 1.1 1.15 1.2 1.25 1.3]*30;
saber_init_temp=25+[0:9];

% Temperature of Heat Sink (Air) - Units = C
saber_air_temp=[1 1 1 1 1 1 1 1 1 1]*20;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Battery thermal model
% Heat capacity, J/kgK  ave heat capacity of module, indexed by module number
ess_mod_cp=[1 1 1 1 1 1 1 1 1 1]*795;
ess_module_mass=0.37824;  % (kg), mass of single module
% Thermal Capacity of Battery - Units = J/C
ess_mod_cpm=ess_module_mass*ess_mod_cp;
ess_module_mass=10*ess_module_mass;      % (kg), mass of 10 modules, used by ADVISOR's gui
ess_voc=10*ess_voc;                      % (V), voltage of 10 modules, used by ADV's gui

% Thermal resistance to heat sink, C/W, indexed by module number
ess_th_res=[1 1 1 1 1 1 1 1 1 1]*1.12; % 1.12 vs 0.1

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Limits
% Per Cell voltage limits
ess_min_volts=2; 
ess_max_volts=3.9; 

% SOC limits, used in the comparator
ess_min_soc=0.01; 
ess_max_soc=0.99; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Other Data
% Next 3 vars Needed for gui
ess_cap_scale=1; % scale factor for module max ah capacity (DO NOT MODIFY FOR SABER MODEL!)
% user definable mass scaling relationship 
ess_mass_scale_fun=inline('(x(1)*ess_module_num+x(2))*(x(3)*ess_cap_scale+x(4))*(ess_module_mass)','x','ess_module_num','ess_cap_scale','ess_module_mass');
ess_mass_scale_coef=[1 0 1 0]; % coefficients in ess_mass_scale_fun


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Saber details
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global vinf
% Boolean to run saber
vinf.saber_cosim.run=1;
% Type of cosimulation to run
%       for battery cosim type = 'ess' (other example types are 'SV', 'DV', 'custom')
vinf.saber_cosim.type='ess';
% Name of sin file to run during cosim, do not include .sin at the end
vinf.saber_cosim.sinname='Lithium_Ion_Pack_10_Module';
% Path of sin file, note vinf.tmppath gives the path of the '...\advisor\tmp\' directory
vinf.saber_cosim.sinpath=strrep(vinf.tmppath,'\tmp\','\models\Saber\Battery\');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Variable names
% e.g. 'alter lib_model.lib1/lib_rc.lib_rc1 = k = 1.0'  for Resistor Rc multiplication factor

% Names of primitives & initial module
prim_names={'lib_model.lib'};

% Names of modules and var_names
% Variables describe the following: 
% k = multiplication factor for re,rc,rt,cb,cc. 
% k = Inverse of Energy Capacity of Battery - Units = 1/Joules for integ
% ic = Initial Battery Voltage Based on SOC - Units = Volts
% init = Initial SOC
% rth = Thermal Resistance to Ground - Units = C/W
% cth = Thermal Capacity of Battery - Units = J/C
% t_init = Initial Temperature of Battery - Units = C
% dc = Temperature of Heat Sink (Air) - Units = C
mod_var_names={'lib_re.lib_re1 = k','lib_rc.lib_rc1 = k','lib_rt.lib_rt1 = k',...
        'lib_cb.lib_cb1 = k','lib_cc.lib_cc1 = k','c.c1 = ic'...
        'integ.integ1 = init','integ.integ1 = k','rtherm.rtherm2 = rth',...
        'ctherm.ctherm1 = cth','ctherm.ctherm1 = t_init','tempsrc.tempsrc1 = dc'};

% Loop through variables to create full list of specific variable names
%       to create vinf.saber_cosim.ess.Vars and values
% e.g. 'alter lib_model.lib4/lib_rc.lib_rc1 = k = 1.0'  
%       for Resistor Rc multiplication factor for 4th module
Value=[];clear FullVars;
for i=1:length(prim_names)
    for j=1:10  %10 modules
        for k=1:length(mod_var_names)
            tmp=[prim_names{i} num2str(j) '/' mod_var_names{k} ];
            if ~exist('FullVars')
                FullVars=tmp;
            else 
                %E.g. to reference a given variable use sytax >> FullVars(1,:)
                FullVars=strvcat(FullVars,tmp);
            end
        end
        Value=[Value; 
            saber_k_re(j);
            saber_k_rc(j);
            saber_k_rt(j);
            saber_k_cb(j);
            saber_k_cc(j);
            saber_init_voc(j);
            saber_init_soc(j);
            saber_k_soc(j);
            ess_th_res(j);
            ess_mod_cpm(j);
            saber_init_temp(j);
            saber_air_temp(j);
        ];
    end
end

% Add other variables if necessary to the string variables and values,
% e.g. 'alter Ten_Module_Voltage_SOC_Error.TMVSE1/v_hi_limit = 3.9' for Maximum individual battery voltage
tmp=strvcat('Ten_Module_Voltage_SOC_Error.TMVSE1/v_hi_limit',...
    'Ten_Module_Voltage_SOC_Error.TMVSE1/v_low_limit',...
    'Ten_Module_Voltage_SOC_Error.TMVSE1/soc_hi_limit',...
    'Ten_Module_Voltage_SOC_Error.TMVSE1/soc_lo_limit');
FullVars=strvcat(FullVars,tmp);
Value = [Value;
    ess_max_volts; 
    ess_min_volts; 
    ess_max_soc; 
    ess_min_soc; 
];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%55
% Output variable names
% Note: length of output variable names must be of length 41
% E.g.
% lib_model.lib1/out(i2var.i2var1)  for current
% v1(ten_module_voltage_soc_error.tmvse1) through v10() for voltages
% s1(ten_module_voltage_soc_error.tmvse1) through s10() for SOC's
% lib_model.lib1/out(tempc2var.tempc2var1) through .lib10 for temperatures
% lib_model.lib1/in(var2th_pwr.var2th_pwr1) through .lib10 for thermal power (heat)

base_name={'lib_model.lib','v',...
        's','lib_model.lib',...
        'lib_model.lib'};
mod_var_names={'/out(i2var.i2var1)','(ten_module_voltage_soc_error.tmvse1)',...
        '(ten_module_voltage_soc_error.tmvse1)','/out(tempc2var.tempc2var1)'...
        '/in(var2th_pwr.var2th_pwr1)'};

% Loop through variables to create full list of specific output variable names
%       to create vinf.saber_cosim.ess.OutVars
clear OutVars;
for i=1:length(base_name)
    for j=1:10  %10 modules
        tmp=[base_name{i} num2str(j) mod_var_names{i} ];
        if ~exist('OutVars')
            OutVars=tmp;
        else 
            %E.g. to reference a given variable use sytax >> OutVars(1,:)
            OutVars=strvcat(OutVars,tmp);
        end
        if i==1 %For current measurement, only need to measure one battery (e.g. 1st module)
            break
        end
    end
end

% Save init outputs in separate variable, needed for initial cond feedback to advisor
ValueInit=[saber_init_voc saber_init_soc saber_init_temp];

% Store in vinf variable, 
% e.g. to reference a given variable use syntax >> vinf.saber_cosim.Vars(1,:)
% To check the order of variables, at the command prompt type >> vinf.saber_cosim.Vars
vinf.saber_cosim.Vars=FullVars;
vinf.saber_cosim.Value=Value;
vinf.saber_cosim.ValueInit=ValueInit;
vinf.saber_cosim.OutVars=OutVars;

% Debug to ensure correct values correspond to string variables
if 0, disp([vinf.saber_cosim.Vars num2str(vinf.saber_cosim.Value)]),end
if 0, disp([vinf.saber_cosim.OutVars]),end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% REVISION HISTORY
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 12/21/01: vhj file created using ess_li7_rc_temp as a base
% 12/28/01: vhj begin Saber details/names
% 01/03/02: vhj loop through 10 modules for names, additional control vars, 
%               add values in vinf.saber_cosim.Value
% 01/07/02: vhj added output variable definition section