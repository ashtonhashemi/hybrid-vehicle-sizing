function bat = Safra
Ns  = 75;
Np  = 3;
Q   = 4;   % Battery Capacity [Ah] 
C   = 250;  % Specific Energy [wh/kg];


% Battery Voltage and Resistance
bat.Q    = Np*Q*60*60;
bat.S    =  [0 10 20 40 60 80 100]/100;
bat.R    = (Ns/Np)*[0.015 0.012 0.011 0.01 0.0095 0.0098 0.01];
bat.V    =  Ns*[3 3.33 3.433 3.5 3.53 3.58 4];
bat.W    =  mean((bat.Q*bat.V)/(3600*C));

end

